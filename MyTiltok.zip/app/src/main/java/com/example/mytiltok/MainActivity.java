package com.example.mytiltok;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.File;
import java.io.IOError;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    private boolean search_flag = false;
    public static List<String> video_path;

    private List<String> GetVideoFileName(String fileDir) {
        List<String> pathList = new ArrayList<>();
        File file = new File(fileDir);
        File[] subFile = file.listFiles();

        for (int iFileLength = 0; iFileLength < subFile.length; iFileLength++) {
            // 判断是否为文件夹
            if (!subFile[iFileLength].isDirectory()) {
                String filename = subFile[iFileLength].getAbsolutePath();
                // 判断是否为MP4结尾
                if (filename.trim().toLowerCase().endsWith(".mp4")) {
                    pathList.add(filename);
                }
                else if (filename.trim().toLowerCase().endsWith(".avi")) {
                    pathList.add(filename);
                }
                else if (filename.trim().toUpperCase().endsWith(".MOV")) {
                    pathList.add(filename);
                }
            }
        }
        return pathList;
    }

    public class SimpleThread extends Thread {
        @Override
        public void run()
        {
            try {
                //Thread.sleep(200);
                video_path = GetVideoFileName(Environment.getExternalStorageDirectory().getAbsolutePath() + "/DCIM/Camera");
                if (! video_path.isEmpty())
                {
                    search_flag = true;
                }
            } catch (IOError e) {
                e.printStackTrace();
            }
        }
    }

    Button start;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //checkPermission
        int permission = ActivityCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE");
        if (permission != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{
                    "android.permission.READ_EXTERNAL_STORAGE",
                    "android.permission.WRITE_EXTERNAL_STORAGE"}, 1);
        }
        else{
            SimpleThread thread = new SimpleThread();
            thread.start();
        }

        start = (Button)findViewById(R.id.btn_main);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(video_path.isEmpty())
                {
                    Toast.makeText(MainActivity.this, "未检索到视频文件，请检查", Toast.LENGTH_SHORT).show();
                }
                startActivity(new Intent(MainActivity.this, ActivityTikTok.class));
                //startActivity(new Intent(MainActivity.this, LocalVideoActivity.class));
            }
        });

        start.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                startActivity(new Intent(MainActivity.this, LocalVideoActivity.class));
                return true;
            }
        });

//        new Thread(new Runnable(){
//            @Override
//            public void run() {
//                int cnt = 10;
//                while(cnt>0) {
//                    try {
//                        Thread.sleep(300);
//                    } catch (InterruptedException e) {
//                        e.printStackTrace();
//                        break;
//                    }
//                }
//            }
//        }).start();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode==0){
            for (int i = 0; i < permissions.length; i++)
            {
                if (grantResults[i]!=-1){
                    //T.showShort(mContext,"权限设置成功");
                    new SimpleThread().start();
                }else {
                    //T.showShort(mContext,"拒绝权限");
                    // 权限被拒绝，弹出dialog 提示去开启权限
                    break;
                }
            }

        }
    }
    private long exitTime = 0;
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0)
        {
            //Toast.makeText(this, "你确定要退出吗", Toast.LENGTH_SHORT).show();
            if((System.currentTimeMillis()-exitTime) > 2000)  //System.currentTimeMillis()无论何时调用，肯定大于2000
            {
                Toast.makeText(getApplicationContext(), "再按一次退出程序",Toast.LENGTH_SHORT).show();
                exitTime = System.currentTimeMillis();
            }
            else
            {
                finish();
                System.exit(0);
            }
            return true;// true 事件不继续传递， false 事件继续传递
        }
        else
        {
            return super.onKeyDown(keyCode, event);
        }
    }
}